class Constants {
  static const String appName = "E-Commerce App";
  static const String appVersion = "1.0.0";
  static const String appDescription = "A sample e-commerce app";
  static const String appAuthor = "Elmer Matthew Japara";
  static const String appEmail = "matt.elmer24@gmail.com";
  static const String appWebsite = "https://github.com/elmermj";
}