enum AppState{
  loading,
  error,
  idle
}