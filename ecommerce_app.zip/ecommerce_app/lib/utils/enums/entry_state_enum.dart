enum EntryState {
  googleLogin, emailRegister, emailLogin
}